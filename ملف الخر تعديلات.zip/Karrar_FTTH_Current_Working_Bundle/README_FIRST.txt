ابدأ بملف 00_HANDOFF_TO_NEW_CHAT.txt.
النسخة المرجعية الشغالة: v1.1.8 + Deno proxy + Deno power probe/extension patch.
v1.1.9 Analytics موجودة للتطوير اللاحق ولم يتم تأكيد نشرها وقت إنشاء الحزمة.
لا تغير مسار الباور الشغال قبل قراءة ملف الأخطاء في 01_FULL_HANDOFF.md.
