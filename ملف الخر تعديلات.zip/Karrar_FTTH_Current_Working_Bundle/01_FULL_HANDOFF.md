# Karrar FTTH — Full Project Handoff

> ملف جامع للتسليم إلى محادثة جديدة. الأسرار الحساسة غير مكتوبة في الشرح النصي، لكن بعض حزم الكود الخاصة قد تحتوي إعدادات تشغيل خاصة.

# مشروع د. كرار FTTH — نقطة الاستلام الآمنة

**تاريخ التوثيق:** 2026-10-05  
**الغرض:** هذا الملف هو المرجع الأول عند فتح محادثة جديدة أو تسليم المشروع لمساعد/مبرمج آخر.  
**قاعدة مهمة:** لا تغيّر المسار الشغال للباور قبل أخذ نسخة احتياطية واختباره على مشترك واحد ثم كابينة كاملة.

## الحالة الشغالة الحالية

الحالة التي أكد المستخدم أنها تعمل بسرعة واستقرار هي:

1. موقع د. كرار يُفتح من رابط **Deno** ويعمل كواجهة/Proxy للموقع.
2. Deno يمرر طلبات الموقع العادية إلى Cloudflare Worker الحالي.
3. بيانات الموقع الأساسية وحساباته وسجلاته تبقى في Cloudflare/D1.
4. **الباور الحي لا يعتمد على Cloudflare Worker** في المسار الأساسي الشغال.
5. الباور يأتي من إضافة المتصفح **Karrar FTTH Direct** مباشرة إلى API الرسمي لـ FTTH.
6. القراءة تُنفذ على دفعات: **3 مشتركين بالتوازي، ثم الثلاثة التالية، وهكذا**.
7. المستخدم أكد أن البحث عن المشترك وقراءة الباور من رابط Deno أصبحت سريعة جداً.
8. تم إضافة اختبار Deno منفصل للباور باستخدام Access Token للتحقق من إمكانية الاتصال، لكن هذا الاختبار ليس بديلاً عن المسار الأساسي إلا بعد اختبار واعتماد واضح.

## الرسم المختصر للحالة الحالية

```text
المستخدم
   |
   v
Deno (واجهة/Proxy)
   |
   v
Cloudflare Worker  ----> D1 / الحسابات / بيانات الموقع / الإشعارات / AI

مسار الباور السريع الحالي:
صفحة كرار --> Karrar FTTH Direct Extension --> admin.ftth.iq --> model.rxPower
                  |
                  +--> اختبار اختياري إلى Deno power-probe (ليس المسار الأساسي)
```

## ممنوعات قبل أي تعديل

- لا تغيّر أو تحذف إضافة **Karrar FTTH Direct** الشغالة.
- لا تعيد الباور إلى Cloudflare Worker؛ FTTH أعاد 520 عدة مرات من هذا المسار.
- لا تستخدم Browser Run للباور الأساسي؛ كان بطيئاً وظهر 429/Timeout.
- لا تغيّر باسورد تطبيق كرار أو أسرار Cloudflare أثناء Deploy إلا بطلب صريح.
- لا تعمل Data Migration تلقائياً على D1.
- لا تغيّر منطق ربط منافذ الكابينة `sourcePort` الموجود في `CabinetTable.jsx`.
- لا تطلب من المستخدم إرسال Access Token أو Refresh Token أو كلمة مرور في المحادثة.
- لا تبني نسخة جديدة لمجرد ظهور كلمة «تعذّر»؛ أولاً استخرج الخطأ الحقيقي والـHTTP status.

## الملفات التي تبدأ بها في محادثة جديدة

1. `01_HANDOFF_TO_NEW_CHAT_AR.txt` — ارفعه للمحادثة الجديدة أولاً.
2. `01_CURRENT_WORKING/karrar-ftth-v1.1.8-direct-fixed-power.zip` — أساس الموقع الشغال قبل Analytics.
3. `02_DENO/karrar-deno-receiver-proxy-v1.0.zip` — Proxy Deno.
4. `02_DENO/karrar-deno-power-probe-v1.zip` — آخر Deno probe + patch للإضافة.
5. `03_PENDING_NOT_DEPLOYED/karrar-ftth-v1.1.9-safe-analytics.zip` — تحديث Analytics مجهز لكن **لم يتم تأكيد نشره**.
6. بعدها اقرأ `07_DOCS/04_ERRORS_DO_NOT_REPEAT_AR.md` قبل كتابة أي كود.

## تنبيه أمني

بعض حزم الكود الخاصة بالمشروع قد تحتوي مفاتيح Bridge أو إعدادات تشغيل خاصة لأنها نسخة عمل خاصة بالمستخدم. **لا تنشر هذا الأرشيف علناً ولا ترفعه إلى GitHub Public.** الوثائق النصية تتجنب كتابة كلمات المرور والتوكنات صراحة.


---

# المعمارية الحالية وتسلسل الطلبات

## 1) المكونات

### Cloudflare Worker
- الاسم: `withered-sun-b4b8`
- الرابط: `https://withered-sun-b4b8.ali07812437089.workers.dev`
- يحتوي API الموقع، الأصول المبنية، Cron، ربط D1، وربط الذكاء/الإشعارات.
- D1 Database ID: `959475f6-2728-4aff-bf86-f69f2f74f8ae`
- Bindings التي ظهرت في Logs:
  - DB = D1
  - BROWSER = Browser Run (موجود، لكن لا يعتمد عليه الباور الأساسي)
  - ASSETS
  - GEMINI_MODEL = `gemini-3.5-flash-lite`
  - GROQ_MODEL = `qwen/qwen3.8-27b`
  - GROQ_VISION_MODEL = `qwen/qwen3.8-27b`

### Deno
- دوره الحالي: Proxy/Receiver أمام Cloudflare + Endpoint اختبار Power Probe.
- Deno لا يعتبر قاعدة البيانات الرئيسية حالياً.
- رابط الاختبار المستخدم داخل config: `https://green-bear-3320.aliabuali.deno.net`؛ يجب تأكيده من Deno Console قبل أي إعداد جديد.

### Karrar FTTH Direct Extension
- Extension Manifest V3.
- مجلد ويندوز المستخدم في النشر المحلي: `C:\Users\Public\Karrar-FTTH-Direct-Bridge`
- تم عمل Backup سابقاً إلى: `C:\Users\Public\Karrar-Working-Backup`
- يدعم workers.dev وdeno.net/deno.dev.
- هو المسار الأساسي السريع للباور حالياً.

### FTTH Official API
- Host: `https://admin.ftth.iq`
- Login endpoint: `/api/auth/Contractor/token`
- Power endpoint: `/api/subscriptions/device/ont?username=USERNAME`
- Power value: `model.rxPower`

## 2) فتح الموقع

```text
Browser
  -> Deno URL
  -> Deno Proxy main.ts
  -> Cloudflare Worker
  -> Assets/API/D1
  -> Deno يعيد الرد للمتصفح
```

Deno يضبط/يمرر headers ويعيد كتابة Location عندما يكون redirect إلى Cloudflare بحيث يبقى المستخدم على دومين Deno.

## 3) البحث وعرض بيانات المشترك

غالبية طلبات واجهة كرار العادية تمر:

```text
UI -> Deno -> Cloudflare API -> D1 / البيانات المتزامنة -> UI
```

إذا كانت هناك مزامنة مع FTTH، فهي جزء خلفي منفصل ولا يجب الخلط بينها وبين Power Direct.

## 4) الباور — المسار المرجعي الشغال

```text
Cabinet/Search UI
   -> direct-power.js / bridge-karrar.js
   -> Chrome/Edge Extension background
   -> admin.ftth.iq/api/subscriptions/device/ont?username=...
   -> Authorization: Bearer accessToken
   -> model.rxPower
   -> UI
```

- المطلوب: Live Power فقط.
- لا تعرض قيمة Cache كأنها Live عند الفشل.
- لا تجعل فشل مشترك واحد يوقف بقية الكابينة.
- concurrency المرجعي: 3 في نفس الوقت، وبعد اكتمالهم تبدأ 3 أخرى.
- المستخدم أكد أن هذا المسار أصبح سريعاً جداً.

## 5) Deno Power Probe

يوجد Endpoint في آخر حزمة Probe:

`POST /__karrar/power-probe`

فكرته: يستلم username + Access Token من المسار المحلي كاختبار، ثم Deno يطلب Power من FTTH. الهدف إثبات إمكانية نقل جزء من العمل إلى Deno بدون تغيير المسار الأساسي مباشرة.

**مهم:** هذا Probe اختبار/مرحلة انتقالية. لا تعتبره المسار الأساسي لمجرد أنه موجود بالكود.

## 6) تسجيل الدخول إلى FTTH

البروتوكول الناجح الذي التقط من الداش:

```text
POST https://admin.ftth.iq/api/auth/Contractor/token
Content-Type: application/x-www-form-urlencoded
Origin: https://admin.ftth.iq
Referer: https://admin.ftth.iq/auth/login
x-client-app: 53d57a7f-3f89-4e9d-873b-3d071bc6dd9f
x-user-role: 0
```

Form:

```text
grant_type=password
scope=openid profile
client_id=
username=<FTTH account>
password=<FTTH password>
```

الرد المعروف يحتوي:
- `access_token`
- `refresh_token`
- `token_type=Bearer`
- `expires_in≈3600`
- `refresh_expires_in≈691200`

لا توثق كلمات المرور أو التوكنات داخل ملفات مشاركة عامة.

## 7) الذكاء

النية المعمارية:
- Qwen أولوية.
- Gemini احتياط.
- الذكاء لا يكون مجرد Keyword matcher؛ يفهم النية.
- إذا سُئل «فلان شكد باوره» يرجع الباور فقط.
- «تفاصيل فلان» يرجع تفاصيل كاملة.
- aliases/مصطلحات تُخزن، مثل «أبو علي = علي حسن محمد» أو «مطفي = غير متصل».
- Analytics v1.1.9 مجهز لإعطائه سياق تغييرات اليوم/الأمس، لكن النشر غير مؤكد.

## 8) الإشعارات وTelegram

تبقى ضمن Cloudflare/Backend الحالي في الخطة المعتمدة، ولا ننقلها إلى Deno الآن.
- إشعارات الموقع.
- Telegram bot عند وجود secrets/config اللازمة.
- لاحقاً: إشعارات تغيير serial بعد التحقق، daily network summary، power trends.

## 9) توزيع الخدمات مستقبلاً

الفكرة الأساسية: مشروع كبير Modular، وليس سيرفر واحد لكل شيء.

```text
Core/Auth/Data      -> Cloudflare + D1
Website Proxy       -> Deno
Power fast path     -> Extension حالياً، ثم خدمة مستقلة فقط بعد نجاح اختبارات كاملة
AI/Notifications    -> تبقى في Core حالياً
Maps                -> Flutter + MapLibre + Offline/PMTiles
Subscriber Portal   -> Module منفصل
Storage             -> خدمة تخزين مناسبة منفصلة
```

الهدف أن أي خدمة تتعطل لا تسقط باقي المشروع.


---

# سجل النسخ والتغييرات

> هذا سجل استرجاع، وليس توصية بإعادة نشر النسخ القديمة.

## v1.0.3
- قاعدة قديمة اعتُبرت مرجعاً لمنطق الكابينات.
- مهم جداً: لا تكسر fallback الخاص بتحديد port من username.

## v1.0.4 / v1.0.5
- محاولات مبكرة لإصلاح النسخة السحابية.
- محفوظة للأرشفة فقط.

## v1.0.6-safe-from-v1.0.3
- هدفها إصلاحات آمنة مع المحافظة على منطق الكابينات القديم.
- بداية التشديد على عدم كسر mapping.

## v1.0.7-mobile-power-drawer
- تعديلات mobile/power/drawer.

## v1.0.8-auto-token-power
- محاولة Auto Token/Power عبر Browser bridge.
- تلتها مشاكل نشر وتداخل مع النسخة القديمة؛ لا تستخدمها كأساس جديد.

## Fix scripts 1.0.9 -> 1.0.13
- `karrar-power-fix-v1.0.9.zip`
- `karrar-power-autorefresh-v1.0.10.cmd`
- `karrar-power-auto-session-v1.0.11.cmd`
- `karrar-power-refresh-fix-v1.0.12.cmd`
- `karrar-power-browser-fallback-v1.0.13.cmd`
- كانت محاولات لفهم refresh/session/Browser Run. لم تكن المسار النهائي.

## v1.1.0-multi-source-ai
أهدافها:
- دعم عدة حسابات/وكلاء FTTH.
- كل مشترك يحمل source association.
- د. كرار المصدر الرئيسي للمشتركين القدامى.
- AI intents + aliases + terminology.
- Deploy مسجل بنجاح:
  - Cloud health: `karrar-ftth-cloud-1.1.0`
  - Version ID: `29b1404e-dc09-4fa5-867f-9789def5c496`

## v1.1.1-dashboard-login-power
- الدخول بالموقع بحساب FTTH نفسه بدلاً من باسورد تطبيق مستقل.
- fallback للمشتركين القدامى بدون source_id إلى المصدر الرئيسي.
- Deploy مسجل:
  - Version ID: `ebc7547a-7c79-4fe5-83bd-3fc7b0e2a2dc`
- لكن Power بقي يفشل بسبب 520.

## v1.1.2-browser-login-power
- محاولة Browser Run لتجاوز 520 بتسجيل الدخول.
- Deploy مسجل:
  - Version ID: `ad4a68f6-fea7-4f65-aa24-a2561d2b30fe`
- بقيت مشاكل Power/520.

## v1.1.3-power-browser-fallback
- إذا طلب Power المباشر رجع 520، Browser Run يجرب نفس ONT request.
- نجح لمشترك واحد أحياناً لكن كان بطيئاً وغير ثابت.

## v1.1.4-fast-power
- Batch/Concurrency لتقليل البطء.
- بقيت مشاكل لأنها ما زالت تعتمد على Browser Run/فتح جلسات ثقيلة.

## v1.1.5-direct-dashboard-power
- نقل Power إلى Extension/Browser Direct نحو FTTH.
- Deploy مسجل:
  - Version ID: `d3eb814d-7699-477c-837b-1bd6bdd802d6`
- تطلب تبويب FTTH مفتوح، وهو قيد غير مرغوب.

## v1.1.6-direct-background-power
- Extension تسجل دخول FTTH بالخلفية، بدون تبويب FTTH مفتوح.
- ظهرت مشكلة أن login flow ما زال يلمس Browser Run/429 في أجزاء.

## v1.1.7-no-browser-login-direct-power
- إلغاء Browser Run من login للمصدر الموجود.
- Deploy مسجل:
  - Version ID: `ddac3ead-2d5c-4e51-ac21-d85351e10334`
- ما زالت كلمة «تعذّر» تظهر قبل ضبط headers/network rules بالكامل.

## v1.1.8-direct-fixed-power — المرجع الحالي
- إصلاح Headers من مستوى Extension باستخدام declarativeNetRequest.
- إظهار أخطاء أوضح وعدم ابتلاع failures.
- Direct Power إلى FTTH.
- المستخدم أكد لاحقاً أن الباور صار **مضبوط وسريع**.
- هذه هي حزمة الأساس التي يجب الرجوع إليها إذا خربت النسخ اللاحقة.

## Deno receiver/proxy v1.0
- Proxy لموقع كرار.
- Patch للإضافة كي تعمل على Deno domains.
- المستخدم أكد أن الموقع يفتح من Deno ويعمل 100%.

## Deno power probe v1
- أضاف endpoint اختباري للباور عبر Deno باستخدام access token.
- عدّل Extension إلى version 1.1.11 في حزمة الاختبار.
- المستخدم أكد بعد الاختبار أن «كلشي تمام».

## v1.1.9-safe-analytics — مجهز وليس مؤكداً أنه منشور
يضيف:
- new subscriber events.
- online/offline transitions.
- power telemetry/trends.
- daily summary + Telegram.
- AI context للاتجاهات.
- serial verification notifications.
- hold 0.5 ثانية للتعديل.

لا يغير:
- Deno proxy.
- Direct power extension.
- 3-at-a-time power path.
- cabinet port mapping.

**لا تعتبره Production deployed إلا إذا ظهر log نشر واضح واختبارات بعده.**


---

# الأخطاء التي حدثت — لا تكررها

## 1) تغيير باسورد الموقع أثناء Deploy
حدث سابقاً أن Deploy قديم غيّر `KARRAR_ADMIN_PASSWORD` وأربك الدخول.

**القاعدة:** Deploy يجب أن يحافظ على الأسرار كما هي. لا prompt لتغيير password، ولا secret put إلا بطلب صريح.

## 2) Data Migration بدون حاجة
المستخدم يريد الحفاظ على D1 والمشتركين.

**القاعدة:** `Existing cloud records preserved; data migration skipped` هو السلوك المطلوب افتراضياً.

## 3) كسر كابينات المشتركين بتعديل port mapping
مرّة اختفى مشتركون من الكابينات لأن mapping تغير.

منطق يجب المحافظة عليه مفهوماً:
- جرب `pointSupplyNumber`
- ثم `port`
- ثم `supplyNumber`
- ثم الجزء الرقمي الأخير من username ضمن 1..16.

لا تغيّر هذا ضمن تحديثات AI/Power/Portal.

## 4) Cloudflare Worker -> FTTH = 520
تكرر:
- `FTTH رجع 520 للوكيل «كرار حمد»`
- `تعذر تسجيل دخول FTTH ... (520) · proxy 520`

هذا ليس سبباً لطلب التوكن من المستخدم مرة أخرى.

## 5) Refresh القديم / Client secret
ظهر:
- `تعذر تجديد جلسة FTTH (401): Client secret not provided in request`

مع أن Password login الناجح الملتقط لم يحتج client_secret.

**القاعدة:** لا تخمن refresh protocol؛ إذا لم يكن مثبتاً لا تبني عليه Production.

## 6) Browser Run
المشاكل التي ظهرت:
- 520
- Timeout
- 429 Rate limit exceeded
- بطء شديد عند فتح session لكل مشترك.

**النتيجة:** Browser Run ليس مسار Power أساسي.

## 7) قراءة Power sequential
كان مشترك واحد يطلع، والبقية تنتظر طويلاً.

**القاعدة الحالية:** 3 concurrent ثم 3 ثم 3. لا تنتظر كل الكابينة لتعرض القيم المكتملة.

## 8) Deno password login
اختبار Deno إلى `/api/auth/Contractor/token` أعاد:
- `TypeError: fetch failed`
- `cause: Error: connection reset`

لا تستنتج من هذا أن Deno كله لا يصل FTTH؛ لاحقاً `/ftth-ping` والـpower probe استُخدما بشكل منفصل ونجحت الحالة حسب المستخدم.

## 9) Extension لم تكن تعمل على Deno
الرسالة:
`تعذر تسليم حساب FTTH إلى إضافة Karrar FTTH Direct: إضافة ... غير مفعلة بهذا المتصفح.`

السبب: manifest matches/host_permissions لم تشمل كل Deno host patterns.

الإصلاح المرجعي:
- `https://*.deno.net/*`
- `https://*.deno.dev/*`

قبل تعديل Power، افحص أن content script injected أصلاً.

## 10) كلمة «تعذّر» العامة
تمت محاولات كثيرة لأن الواجهة كانت تخفي الخطأ الحقيقي.

**القاعدة:** كل فشل يجب أن يترك status/سبب قابل للفحص، مثل 401/403/429/520/timeout/FTTH did not return rxPower.

## 11) Health check script
ظهرت رسائل:
- `FINDSTR: Cannot open C:\WINDOWS\TEMP\karrar-health.txt`
- `curl: Could not resolve host: |`
- `curl: Could not resolve host: findstr`

هذه أخطاء صياغة/ملف مؤقت في سكربت الفحص، وليست دائماً فشل Deploy.

أثبت النشر من:
- `Uploaded withered-sun-b4b8`
- `Deployed withered-sun-b4b8 triggers`
- `/healthz` JSON version.

## 12) Power cache
المستخدم طلب Power Live فقط.

**ممنوع:** عند فشل القراءة، عرض cached rxPower وكأنه live.

## 13) محاولة حل كل شيء في نسخة واحدة
هذا سبب regressions سابقاً.

**القاعدة:**
- Power update منفصل.
- Cabinet retention/لون البني منفصل.
- Subscriber Portal منفصل.
- Analytics منفصل.
- Maps منفصل.

## 14) طلب الأسرار مرة ثانية
المستخدم أعطى سابقاً Tokens/Credentials أثناء التحقيق.

**القاعدة:** لا تطلب إرسالها في المحادثة. استخدم Env/Secrets أو UI محلي فقط.

## 15) ادعاء النجاح قبل الاختبار
لا تقل «100%» قبل أن يختبر المستخدم على:
- مشترك واحد.
- 6+ مشتركين في كابينة.
- كابينة ثانية.
- بحث مباشر.

الحالة الحالية تمت الموافقة عليها من المستخدم بعد هذه المراحل العملية.


---

# المتطلبات الثابتة والـBacklog

## A. الكابينات

### مطلوب لاحقاً — لم ينفذ بعد
- كل شخص مرتبط بالكابينة يبقى ظاهر حتى إذا ترك الخدمة.
- تارك الخدمة يظهر **باللون البني**.
- لا تغيّر port/position عند تنفيذ هذا.
- لا تحذف subscriber record لمجرد status departed/inactive إذا نحتاجه في تاريخ الكابينة.
- هذا التعديل يجب أن يكون منفصلاً عن Power.

## B. بوابة المشترك

المطلوب بالتفصيل:
- إنشاء بوابة للمشترك من صفحة تفاصيله.
- البحث/الاختيار بالـusername أو الاسم الرباعي.
- لكل مشترك جهاز أو Browser واحد فقط فعال.
- عند جهاز جديد: يحتاج ربط/موافقة أو فك الجهاز السابق من الإدارة.
- المدير يستطيع الدخول كـ«مشترك» ليرى نفس تجربة البوابة ويعدلها.
- تغيير رمز المشترك بضغط مستمر **0.5 ثانية**، وليس 1 ثانية.
- Eye icon لإظهار/إخفاء رمز الاشتراك.
- Eye icon لإظهار/إخفاء رمز بوابة المشترك.
- من صفحة Subscriber Details، الضغط على «البوابة» يفتح إدارة هذا المشترك بالذات:
  - حالة البوابة.
  - الجهاز المرتبط.
  - آخر دخول.
  - تغيير الرمز.
  - فك الربط.
  - الموافقات.
  - الإعدادات والتخصيصات.
  - Audit log: من غيّر ماذا ومتى.
- لا تستخدم plaintext password storage.
- لا تجعل Device Binding للإدارة نفسها؛ الربط المطلوب لبوابة المشترك.
- لا تغيّر FTTH account password إلا بأمر صريح.

## C. Power

- Live only.
- `model.rxPower` فقط.
- 3 concurrent ثم 3.
- سريع من البحث ومن الكابينة.
- لا Browser Run كمسار أساسي.
- لا Cached fallback كأنه Live.
- لا تغيّر المسار المرجعي الشغال قبل proving البديل.

## D. Analytics / Notifications

المطلوب:
- عدد المشتركين الجدد يومياً.
- من كان Offline وصار Online.
- من كان Online وصار Offline.
- تغير Power old/new.
- من كان Power عالي/ضعيف وتحسن إلى طبيعي.
- من كان طبيعي وساء.
- عدد الطبيعي الذين تحسنوا/ساءوا.
- Daily summary داخل الموقع.
- نفس الملخص إلى Telegram عند تفعيل البوت.
- AI يستطيع تحليل هذه الأحداث حسب اليوم/الأمس/الفترة.
- AI يتعلم aliases والمصطلحات ضمن memory layer للموقع.
- Package v1.1.9-safe-analytics جهز جزءاً كبيراً من هذا لكنه غير مؤكد النشر.

## E. Serial changes

- عند طلب تغيير Serial: لا تعتبر العملية مكتملة بمجرد HTTP success.
- سجلها `verifying`.
- backend/cron يراجع FTTH لاحقاً.
- عند ظهور serial الجديد فعلياً:
  - site notification.
  - Telegram notification.
  - audit event.
- يجب أن يصل الإشعار حتى لو المستخدم أغلق الصفحة.

## F. Maps / Field App

الخطة:
- لا نسخ MAPS.ME حرفياً ولا الاعتماد على تحديثاته.
- تطبيق واحد Flutter/Dart يعمل Android + iOS.
- MapLibre للخرائط.
- Offline maps / PMTiles قدر الإمكان.
- Features مستقبلية:
  - FAT/FDT/cabinets.
  - routes/cables.
  - GPS.
  - maintenance points.
  - faults.
  - teams/vehicles لاحقاً.
  - subscriber drill-down من نقطة الخريطة.
- الخريطة نفسها تكون محلية قدر الإمكان، والسيرفر يرسل deltas/data فقط.

## G. توزيع المشروع على خدمات

- لا تجعل كل شيء على سيرفر واحد.
- الخدمات يجب أن تكون قابلة للنقل.
- استخدم Free tiers ما دام ذلك عملياً، لكن لا تفترض ضمان المجانية للأبد.
- Core/Auth/Data على Cloudflare/D1 حالياً.
- Deno Proxy/خدمات مستقلة عند الحاجة.
- Maps module منفصل.
- AI/Notifications تبقى حيث هي حتى يوجد سبب تقني للنقل.
- Power لا يُنقل إلا بعد اختبار endpoint البديل بدون التأثير على المسار الحالي.

## H. UI/UX القديمة التي يجب تذكرها

- Glass/iPhone-like blur.
- Light/Dark.
- blur slider 0-100.
- sidebar: background behind strongly blurred، الصفحة خلفه لا scroll، sidebar itself scrolls.
- cabinet names كاملة وتلتف إذا طويلة.
- unified search حسب username/serial/phone/name.
- mobile no overlap.
- Arabic Fusha في مشروع د. كرار ما لم يطلب خلاف ذلك.


---

# النشر والاسترجاع الآمن

## روابط Cloudflare

Admin:
`https://withered-sun-b4b8.ali07812437089.workers.dev/`

Subscriber:
`https://withered-sun-b4b8.ali07812437089.workers.dev/subscriber.html`

Health:
`https://withered-sun-b4b8.ali07812437089.workers.dev/healthz`

Worker name:
`withered-sun-b4b8`

D1:
`959475f6-2728-4aff-bf86-f69f2f74f8ae`

## مجلدات ويندوز المهمة

Cloudflare working repo ظهر في Logs تحت:
`C:\Users\علي ابو علي\Ali-PC-Agent\cf-live\withered-sun-b4b8`

Extension runtime folder:
`C:\Users\Public\Karrar-FTTH-Direct-Bridge`

Backup folder الذي طلب عمله:
`C:\Users\Public\Karrar-Working-Backup`

## قاعدة Deploy

1. لا تعدل Production source مباشرة دون Backup.
2. Build أولاً.
3. إذا Build فشل، لا deploy.
4. Deploy بدون secret changes.
5. لا migration افتراضياً.
6. تحقق `/healthz`.
7. اختبر Login.
8. اختبر Search.
9. اختبر Power واحد.
10. اختبر Cabinet 6+ subscribers.
11. اختبر Cabinet ثانية.

## استرجاع Power إذا خرب تحديث لاحق

المرجع:
`karrar-ftth-v1.1.8-direct-fixed-power.zip`

ثم آخر Deno/Extension patches:
- `karrar-deno-receiver-proxy-v1.0.zip`
- `karrar-deno-power-probe-v1.zip`

لا ترجع إلى Browser Run versions ما لم يكن الهدف فقط التحقيق.

## نسخة Analytics

`karrar-ftth-v1.1.9-safe-analytics.zip`

حالتها في وقت هذا التوثيق:
**Prepared / not confirmed deployed.**

إذا قررت نشرها:
- راجع diff أولاً.
- لا تستبدل Extension/Deno files.
- خذ D1 backup إن أمكن.
- تأكد أن الباور direct path لم يتغير.

## Deno

الـPlayground الحالي احتوى Proxy ثم أضيف Power Probe.

الخطأ القديم `connection reset` كان في Password Login test إلى FTTH، وليس دليلاً أن Deno Proxy نفسه فاشل.

عند تغيير Deno code:
- احتفظ بنسخة main.ts الشغالة.
- لا ترسل credentials بالنص داخل source.
- استخدم Env/Secrets إذا احتجت لاحقاً.
- لا تغيّر Production Power path إلا بعد اختبار endpoint منفصل.


---

# الأمن والأسرار

## ما لا يُكتب في محادثة أو README عام

- FTTH username/password.
- access_token.
- refresh_token.
- Cloudflare API tokens.
- Telegram bot token.
- Bridge shared keys.

## الوضع الحالي

بعض حزم العمل الخاصة قد تحتوي مفتاح Bridge ضمن config لأن الهدف منها تشغيل النظام الحالي. لذلك:
- اعتبر الأرشيف الكامل **خاص**.
- لا ترفعه إلى GitHub Public.
- إذا احتجت مشاركة عامة، أنشئ نسخة Sanitized أولاً.

## تخزين بوابة المشترك

عند تنفيذها:
- password hashing وليس تشفير reversible إذا كان الرمز للتحقق فقط.
- إذا يلزم كشف الرمز للمدير بعين، فبدلاً من password التقليدي يمكن اعتماد generated portal PIN secret مشفر بمفتاح server-side، مع audit log.
- one-device binding يعتمد device token عشوائي، وليس fingerprint عدواني.
- revoke/rotate من لوحة الإدارة.

## FTTH account

- لا تغيّر FTTH password أو application password من script.
- Credential UI يستخدم HTTPS.
- لا يعاد إرسال كلمة المرور إلى frontend بعد حفظها.

## Deno probe

Power Probe يستقبل Access Token للاختبار. إذا تحول لاحقاً إلى Production:
- لا تحفظ Access Token في logs.
- استخدم short TTL.
- shared bridge key يجب تدويره.
- الأفضل لاحقاً mutual signed request / HMAC أو token قصير من Core API.


---

# حالة التحليلات والإشعارات

## الموجود المؤكد في النظام قبل v1.1.9

- Notifications endpoint موجود.
- Source errors كانت تُسجل في notifications.
- Cron موجود في Cloudflare (`schedule: * * * * *`).
- AI gateway موجود.
- Telegram integration code موجود في المشروع، تشغيله يعتمد secrets/config.
- بيانات subscriber/status موجودة ويمكن مزامنتها.

## ما لم يكن متوفراً بشكل مكتمل قبل v1.1.9

- daily count للمشتركين الجدد كحدث مستقل.
- history للـOnline/Offline transitions.
- history للـrxPower changes.
- old/new power trend analysis.
- daily network summary شامل.
- AI context من network events.
- serial completion verification notification بعد رؤية القيمة الجديدة في FTTH.

## v1.1.9-safe-analytics

مجهز لإضافة:
- Network change event history.
- New subscriber event.
- Online/offline transition event.
- Status change event.
- observed serial changes.
- Non-blocking telemetry بعد successful direct power read.
- Power delta tracking عند تغير >= 0.5 dBm.
- Daily network summary.
- Telegram daily summary إذا config موجود.
- AI context اليوم/الأمس.
- Serial verify by cron.
- hold 0.5s.

## تنبيه

هذه الحزمة لا تُعتبر منشورة لمجرد وجودها في الأرشيف. يجب رؤية Deploy log ثم اختبار Production.


---

# خطة الخرائط والتوسع إلى موقع/نظام عملاق

## الهدف

تطوير النظام من Dashboard FTTH إلى منصة ميدانية كبيرة بدون أن يصبح كل Feature سبباً لإبطاء Power أو إسقاط Core.

## تطبيق الخرائط

الاختيار المقترح:
- Flutter / Dart.
- Android + iOS من مشروع واحد.
- MapLibre.
- Offline-first.
- PMTiles/GeoJSON حسب الحاجة.

لا نعتمد على تعديل تطبيق MAPS.ME نفسه كمنتجنا الرئيسي؛ نبني تطبيقنا الخاص حتى نتحكم بالتحديثات والهوية والربط.

## Modules مقترحة

1. Core Subscribers.
2. Cabinets/FAT/FDT.
3. Power Service.
4. Maps/GPS.
5. Maintenance/Tickets.
6. Subscriber Portal.
7. AI/Analytics.
8. Notifications/Telegram.
9. Documents/Images.
10. Inventory.
11. Field Teams.
12. Payments/Collection.

## قاعدة الأداء

كل module ثقيل يجب أن:
- لا يكون synchronous blocking لمسار Power.
- لا يحمّل كل البيانات عند فتح الصفحة.
- يستخدم pagination/deltas/cache مناسب.
- يفشل لوحده بدون إسقاط بقية النظام.

## Free services

المستخدم يريد خدمات مجانية دائماً قدر الإمكان. لا توجد خدمة يمكن ضمان أنها ستبقى مجانية للأبد، لذلك المعمارية يجب أن تكون portable.

- Cloudflare يبقى Core حالياً.
- Deno يستخدم كProxy/خدمة منفصلة طالما Free tier مناسب.
- الخرائط تكون Offline/local لتقليل الاعتماد على السيرفر.
- التخزين الكبير لاحقاً يذهب إلى object storage مناسب بدل D1.


---

# مراجع تقنية دقيقة من المشروع

## Cabinet port fallback الذي يجب الحفاظ عليه

المعنى المرجعي للمنطق:

```js
function sourcePort(x){
  for(const v of [x?.pointSupplyNumber,x?.port,x?.supplyNumber]){
    const n=Number(String(v??'').match(/\d{1,2}/)?.[0]);
    if(n>=1&&n<=16)return n
  }
  const u=String(x?.username||'');
  const m=u.match(/(?:^|[-_.])(\d{1,2})(?:[A-Za-z]*)$/);
  const n=Number(m?.[1]);
  return n>=1&&n<=16?n:null
}
```

لا تعدله بدون Test dataset للكابينات.

## Power endpoint

```text
GET https://admin.ftth.iq/api/subscriptions/device/ont?username=USERNAME
Authorization: Bearer ACCESS_TOKEN
```

Response known:

```json
{
  "model": {
    "status": {
      "id": 0,
      "entityType": "OntStatus",
      "displayValue": "Up",
      "description": null
    },
    "rxPower": -23.67
  }
}
```

القيمة المطلوبة: `model.rxPower`.

## Login endpoint

```text
POST https://admin.ftth.iq/api/auth/Contractor/token
```

Form:

```text
grant_type=password
scope=openid profile
client_id=
username=...
password=...
```

Known headers:

```text
accept: application/json, text/plain, */*
content-type: application/x-www-form-urlencoded
origin: https://admin.ftth.iq
referer: https://admin.ftth.iq/auth/login
x-client-app: 53d57a7f-3f89-4e9d-873b-3d071bc6dd9f
x-user-role: 0
```

## Token lifetimes observed

- Access ≈ 3600 sec.
- Refresh ≈ 691200 sec (8 days).

## Current concurrency target

```text
Batch 1: 3 subscribers in parallel
Batch 2: next 3
Batch 3: next 3
...
```

A single slow subscriber must have a timeout and must not block the rest forever.
